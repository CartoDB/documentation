## Introduction

The CARTO 3 Workspace includes options for managing your CARTO account information. 

From the *Account Settings* menu, you can view and edit your account name, view the details of your account plan, register existing apps, invite users to join your account and delete your account.

GENERAL IMAGE