## View data table

Once you have added your datasets to the map, you can visualize the data table. Click the *Show data table* button and your dataset table will be shown. 

![Map created](/img/cloud-native-workspace/maps/map_view_table2.png)

By clicking the *tree dots* icon the Column Context menu will reveal additional options like: Sort on this column, ascending or descending, Pin the column so you can freeze it in the first position, and copy column data.

![Map created](/img/cloud-native-workspace/maps/map_view_table_column2.png)